package com.example.juanlondono11.myapplication;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class RegistroActivity extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);
        Button button = (Button)findViewById(R.id.btnReg);
        button.setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {
        String name = ((EditText)findViewById(R.id.txtRegName)).getText().toString();
        String password = ((EditText)findViewById(R.id.txtRegPass)).getText().toString();

        if (name.isEmpty() || password.isEmpty()){
            Toast.makeText(getApplicationContext(),"Faltan campos por rellenar", Toast.LENGTH_SHORT).show();
        }else{
            SharedPreferences datos = getSharedPreferences("USUARIOS", 0);
            SharedPreferences.Editor editor = datos.edit();
            editor.putString("NAME", name );
            editor.putString("PASSWORD", password);
            editor.commit();
            Intent intent = new Intent(getApplicationContext(),MainActivity.class);
            startActivity(intent);

        }


    }
}
